#pragma once

#include <agile.h>
#include <array>
#include <d2d1_2.h>
#include <d3d11_4.h>
#include <DirectXColors.h>
#include <dwrite_2.h>
#include <map>
#include <mutex>
#include <wincodec.h>
#include <WindowsNumerics.h>
#include <collection.h>
#include <ppltasks.h>

#include "App.xaml.h"
#include <list>

